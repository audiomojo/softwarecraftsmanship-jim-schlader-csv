package com.henryschein.dataservices.csvtranslator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CsvtranslatorApplication {

    public static void main(String[] args) {
        SpringApplication.run(CsvtranslatorApplication.class, args);
    }

}
