package com.henryschein.dataservices.csvtranslator.services;

import com.henryschein.dataservices.csvtranslator.csvtranslators.ReverseTranslator;
import com.henryschein.dataservices.csvtranslator.interfaces.Translator;
import com.henryschein.dataservices.csvtranslator.parser.CSVParser;
import com.henryschein.dataservices.csvtranslator.csvtranslators.BracketTranslator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;


@Service
public class CSVTranslatorService {

    @Autowired
    CSVParser csvParser;

    private static HashMap<String, Translator> translators = new HashMap<>();

    static {
        Translator bracketTranslator = new BracketTranslator();
        Translator reverseTranslator = new ReverseTranslator();
        translators.putIfAbsent("bracket", bracketTranslator);
        translators.putIfAbsent("reverse", reverseTranslator);
    }

    public Translator getTranslator(String type){
        return this.translators.get(type);
    }

    public String translateCSV(String csv, String type) {
        List<List<String>> parsedCSV = csvParser.parseCSV(csv);
        Set<String> keys = translators.keySet();
        if(!keys.contains(type)) type = "bracket";
        return translators.get(type).Translate(parsedCSV);
    }
}
