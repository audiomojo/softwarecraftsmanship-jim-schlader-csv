package com.henryschein.dataservices.csvtranslator;

import com.henryschein.dataservices.csvtranslator.csvtranslators.BracketTranslator;
import com.henryschein.dataservices.csvtranslator.csvtranslators.ReverseTranslator;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class ReverseTranslatorTests  {
    private ReverseTranslator translator;

    @Before
    public void setUp() throws Exception {

    }

    @Test
    public void Test_TranslateCSVData_EmptyString() {

    }

    @Test
    public void Test_TranslateCSVData_SingleLine() {

    }

    @Test
    public void Test_Multiple_Items_in_List() {

    }

    @Test
    public void Test_Multiple_Lines_with_Multiple_Items() {

    }

}
